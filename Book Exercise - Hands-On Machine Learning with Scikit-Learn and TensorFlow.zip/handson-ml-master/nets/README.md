This directory was copied from:
https://github.com/tensorflow/models/blob/master/slim/nets

On Sept. 25th, 2016. Commit:
https://github.com/tensorflow/models/commit/65fad62dc6daca5a72c204013824cc380939d457
