# Introduction To RNNs in Tensorflow

Placeholder for future purposes
