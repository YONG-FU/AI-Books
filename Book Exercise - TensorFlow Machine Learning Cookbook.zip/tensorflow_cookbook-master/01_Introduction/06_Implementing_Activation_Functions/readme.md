# Activation Functions

This script plots many various activation functions in Tensorflow.

![Activation Functions](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/01_Introduction/images/06_activation_funs1.png "Activation Functions")

![Activation Functions](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/01_Introduction/images/06_activation_funs2.png "Activation Functions")

### TO DO

 - Add more documentation, explanations, and resources.

