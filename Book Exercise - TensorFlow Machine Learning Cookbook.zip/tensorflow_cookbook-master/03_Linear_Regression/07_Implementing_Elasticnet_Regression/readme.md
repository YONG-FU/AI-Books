# Implementing Elasticnet Regression

![Elasticnet Regression Loss](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/03_Linear_Regression/images/07_elasticnet_reg_loss.png "Elasticnet Regression Loss")

