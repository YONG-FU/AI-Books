# Using the Cholesky Decomposition Method

Here we implement solving 2D linear regression via the Cholesky decomposition in Tensorflow.

# Model

Given A * x = b, and a Cholesky decomposition such that A = L*L' then we can get solve for x via
 1. Solving L * y = t(A) * b for y
 2. Solving L' * x = y for x.

# Graph of linear fit

![Cholesky decomposition](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/03_Linear_Regression/images/02_Cholesky_Decomposition.png "Cholesky decomposition")
