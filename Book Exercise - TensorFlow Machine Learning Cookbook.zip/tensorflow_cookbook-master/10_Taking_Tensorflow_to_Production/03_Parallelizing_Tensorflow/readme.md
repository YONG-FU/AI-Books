# Parallelizing Tensorflow

Placeholder for future purposes
