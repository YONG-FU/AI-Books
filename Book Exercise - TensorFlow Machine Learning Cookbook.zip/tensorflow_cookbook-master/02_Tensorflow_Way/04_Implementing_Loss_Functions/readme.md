# Implementing Loss Functions

## Summary

In this script, we will show how to implement different loss functions in tensorflow

## Plots of the Loss Functions

The output of the script in this section plots the various loss functions:

![Loss Functions 1](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/02_Tensorflow_Way/images/04_loss_fun1.png "Loss Functions 1")

![Loss Functions 2](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/02_Tensorflow_Way/images/04_loss_fun2.png "Loss Functions 2")
