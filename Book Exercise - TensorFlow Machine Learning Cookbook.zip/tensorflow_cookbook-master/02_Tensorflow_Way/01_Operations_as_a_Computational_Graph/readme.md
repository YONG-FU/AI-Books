# Operations as a Computational Graph

## Summary

In this script, we create an array and feed it into a placeholder.  We then multiply it by a constant.

## Computational Graph Output

Viewing the computational graph in Tensorboard, as created by the script:

![One Operation](https://github.com/nfmcclure/tensorflow_cookbook/blob/master/02_Tensorflow_Way/images/01_Operations_on_a_Graph.png "An Operation on a Graph")
